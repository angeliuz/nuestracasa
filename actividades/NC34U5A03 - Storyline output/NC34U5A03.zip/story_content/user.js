function ExecuteScript(strId)
{
  switch (strId)
  {
      case "67tgicSmrhi":
        Script1();
        break;
      case "6B6g4c88Jnd":
        Script2();
        break;
      case "6joDIFiz1nM":
        Script3();
        break;
      case "64AuS0iqR5X":
        Script4();
        break;
      case "69p1umIIel2":
        Script5();
        break;
      case "6Cg6FcKhJSx":
        Script6();
        break;
      case "5xNC69S1BX1":
        Script7();
        break;
      case "6mFvSEfc9JU":
        Script8();
        break;
      case "6WSaBcLEn3s":
        Script9();
        break;
      case "68rVhFI4lQF":
        Script10();
        break;
      case "6riiNIbsQwt":
        Script11();
        break;
      case "6pzkrWIDRNG":
        Script12();
        break;
      case "5nnTHHEg5Ek":
        Script13();
        break;
      case "5vDUgOh7FLQ":
        Script14();
        break;
      case "6ZkXyavFd8d":
        Script15();
        break;
      case "6fG7szmSLGR":
        Script16();
        break;
      case "5XDWYeucnLj":
        Script17();
        break;
      case "6oCzYVC3Ovn":
        Script18();
        break;
      case "66gyhRmr07v":
        Script19();
        break;
      case "6QXTP8XDxvW":
        Script20();
        break;
      case "67GRyno311k":
        Script21();
        break;
      case "6NIEmZDsdAN":
        Script22();
        break;
      case "67dz02kBPDK":
        Script23();
        break;
      case "5wiCkPTesHc":
        Script24();
        break;
      case "5fir2VIA0w3":
        Script25();
        break;
      case "6rLBJQPAQgD":
        Script26();
        break;
      case "6ZU5rlvebCG":
        Script27();
        break;
      case "5hz3bIWFjy3":
        Script28();
        break;
      case "5jsOpME5P1t":
        Script29();
        break;
      case "5xlfKP14DJN":
        Script30();
        break;
      case "5VfX3nj3crJ":
        Script31();
        break;
      case "6EDd9OvgQYb":
        Script32();
        break;
      case "5gXoXa27YMa":
        Script33();
        break;
      case "5bXrKsxz7fG":
        Script34();
        break;
      case "6Tpi9Rr6cWo":
        Script35();
        break;
      case "6bycUXjyFhi":
        Script36();
        break;
  }
}

function Script1()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

window.setCodigoDiapositiva(cod_actividad, cod_actividad+"D01");
window.setCodigoDiapositiva(cod_actividad, cod_actividad+"D02");
window.setCodigoDiapositiva(cod_actividad, cod_actividad+"D03");
window.setCodigoDiapositiva(cod_actividad, cod_actividad+"D04");
window.setCodigoDiapositiva(cod_actividad, cod_actividad+"D05");
window.setCodigoDiapositiva(cod_actividad, cod_actividad+"D06");
window.setCodigoDiapositiva(cod_actividad, cod_actividad+"D07");
window.setCodigoDiapositiva(cod_actividad, cod_actividad+"D08");
window.setCodigoDiapositiva(cod_actividad, cod_actividad+"D09");
window.setCodigoDiapositiva(cod_actividad, cod_actividad+"D10");
window.setCodigoDiapositiva(cod_actividad, cod_actividad+"D11");
window.setCodigoDiapositiva(cod_actividad, cod_actividad+"D12");
window.setCodigoDiapositiva(cod_actividad, cod_actividad+"D13");
window.setCodigoDiapositiva(cod_actividad, cod_actividad+"D14");

window.getCodigoDiapositiva(cod_actividad, cod_diapositiva);
window.getIntentos(cod_actividad, cod_diapositiva);

console.log("Inicializa actividades en BD",cod_actividad+"D01");
}

function Script2()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

var respuesta_01 = window.getRespuesta(cod_actividad, cod_actividad+"D01");
var respuesta_02 = window.getRespuesta(cod_actividad, cod_actividad+"D02");
var respuesta_03 = window.getRespuesta(cod_actividad, cod_actividad+"D03");
var respuesta_04 = window.getRespuesta(cod_actividad, cod_actividad+"D04");
var respuesta_05 = window.getRespuesta(cod_actividad, cod_actividad+"D05");
var respuesta_06 = window.getRespuesta(cod_actividad, cod_actividad+"D06");
var respuesta_07 = window.getRespuesta(cod_actividad, cod_actividad+"D07");
var respuesta_08 = window.getRespuesta(cod_actividad, cod_actividad+"D08");
var respuesta_09 = window.getRespuesta(cod_actividad, cod_actividad+"D09");
var respuesta_10 = window.getRespuesta(cod_actividad, cod_actividad+"D10");
var respuesta_11 = window.getRespuesta(cod_actividad, cod_actividad+"D11");
var respuesta_12 = window.getRespuesta(cod_actividad, cod_actividad+"D12");
var respuesta_13 = window.getRespuesta(cod_actividad, cod_actividad+"D13");
var respuesta_14 = window.getRespuesta(cod_actividad, cod_actividad+"D14");

var solucion_01 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D01");
var solucion_02 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D02");
var solucion_03 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D03");
var solucion_04 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D04");
var solucion_05 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D05");
var solucion_06 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D06");
var solucion_07 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D07");
var solucion_08 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D08");
var solucion_09 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D09");
var solucion_10 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D10");
var solucion_11 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D11");
var solucion_12 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D12");
var solucion_13 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D13");
var solucion_14 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D14");

var intento_01 = window.getIntentos(cod_actividad, cod_actividad+"D01");
var intento_02 = window.getIntentos(cod_actividad, cod_actividad+"D02");
var intento_03 = window.getIntentos(cod_actividad, cod_actividad+"D03");
var intento_04 = window.getIntentos(cod_actividad, cod_actividad+"D04");
var intento_05 = window.getIntentos(cod_actividad, cod_actividad+"D05");
var intento_06 = window.getIntentos(cod_actividad, cod_actividad+"D06");
var intento_07 = window.getIntentos(cod_actividad, cod_actividad+"D07");
var intento_08 = window.getIntentos(cod_actividad, cod_actividad+"D08");
var intento_09 = window.getIntentos(cod_actividad, cod_actividad+"D09");
var intento_10 = window.getIntentos(cod_actividad, cod_actividad+"D10");
var intento_11 = window.getIntentos(cod_actividad, cod_actividad+"D11");
var intento_12 = window.getIntentos(cod_actividad, cod_actividad+"D12");
var intento_13 = window.getIntentos(cod_actividad, cod_actividad+"D13");
var intento_14 = window.getIntentos(cod_actividad, cod_actividad+"D14");

var logro_01 = window.getLogro(cod_actividad, cod_actividad+"D01");
var logro_02 = window.getLogro(cod_actividad, cod_actividad+"D02");
var logro_03 = window.getLogro(cod_actividad, cod_actividad+"D03");
var logro_04 = window.getLogro(cod_actividad, cod_actividad+"D04");
var logro_05 = window.getLogro(cod_actividad, cod_actividad+"D05");
var logro_06 = window.getLogro(cod_actividad, cod_actividad+"D06");
var logro_07 = window.getLogro(cod_actividad, cod_actividad+"D07");
var logro_08 = window.getLogro(cod_actividad, cod_actividad+"D08");
var logro_09 = window.getLogro(cod_actividad, cod_actividad+"D09");
var logro_10 = window.getLogro(cod_actividad, cod_actividad+"D10");
var logro_11 = window.getLogro(cod_actividad, cod_actividad+"D11");
var logro_12 = window.getLogro(cod_actividad, cod_actividad+"D12");
var logro_13 = window.getLogro(cod_actividad, cod_actividad+"D13");
var logro_14 = window.getLogro(cod_actividad, cod_actividad+"D14");

window.getRespuestaMultiple(cod_actividad, cod_actividad+"D03", "texto1", 1);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D03", "texto2", 2);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D03", "texto3", 3);

window.getRespuestaMultiple(cod_actividad, cod_actividad+"D04", "texto4", 1);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D04", "texto5", 2);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D04", "texto6", 3);

window.getRespuestaMultiple(cod_actividad, cod_actividad+"D05", "texto7", 1);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D05", "texto8", 2);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D05", "texto9", 3);

window.getRespuestaMultiple(cod_actividad, cod_actividad+"D06", "multi1", 1);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D06", "multi2", 2);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D06", "multi3", 3);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D06", "multi4", 4);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D06", "multi5", 5);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D06", "multi6", 6);

window.getRespuestaMultiple(cod_actividad, cod_actividad+"D07", "texto10", 1);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D07", "texto11", 2);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D07", "texto12", 3);

window.getRespuestaMultiple(cod_actividad, cod_actividad+"D08", "texto13", 1);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D08", "texto14", 2);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D08", "texto15", 3);

window.getRespuestaMultiple(cod_actividad, cod_actividad+"D14", "drag1", 1);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D14", "drag2", 2);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D14", "drag3", 3);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D14", "drag4", 4);
window.getRespuestaMultiple(cod_actividad, cod_actividad+"D14", "drag5", 5);

console.log("trae info guardada en BD");
}

function Script3()
{
  var p = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

window.setEstadoSolucionario(cod_actividad, cod_diapositiva)

console.log("estado solucionario: ",window.getEstadoSolucionario(cod_actividad, cod_diapositiva));
}

function Script4()
{
  var p = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

window.setEstadoSolucionario(cod_actividad, cod_diapositiva)

console.log("estado solucionario: ",window.getEstadoSolucionario(cod_actividad, cod_diapositiva));
}

function Script5()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

var texto1 = localStorage.getItem(cod_diapositiva + "_texto1");
var texto2 = localStorage.getItem(cod_diapositiva + "_texto2");
var texto3 = localStorage.getItem(cod_diapositiva + "_texto3");

console.log(texto1,texto2,texto3);
}

function Script6()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");
var texto1 = p.GetVar("texto1");
var texto2 = p.GetVar("texto2");
var texto3 = p.GetVar("texto3");
var respuesta = [texto1,texto2,texto3];
var respuesta_03 = p.GetVar("respuesta_03");

if (respuesta != respuesta_03) {
  console.log("no es igual");
  window.setIntentos(cod_actividad, cod_diapositiva);
  //window.setLogro(cod_actividad, cod_diapositiva, logro);
  window.setRespuesta(cod_actividad, cod_diapositiva, respuesta);
} else {
  console.log("es igual");
}

console.log("intentos: ", window.getIntentos(cod_actividad, cod_diapositiva));
}

function Script7()
{
  var p = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

window.setEstadoSolucionario(cod_actividad, cod_diapositiva)

console.log("estado solucionario: ",window.getEstadoSolucionario(cod_actividad, cod_diapositiva));
}

function Script8()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

var texto4 = localStorage.getItem(cod_diapositiva + "_texto4");
var texto5 = localStorage.getItem(cod_diapositiva + "_texto5");
var texto6 = localStorage.getItem(cod_diapositiva + "_texto6");

console.log(texto4,texto5,texto6);
}

function Script9()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");
var texto4 = p.GetVar("texto4");
var texto5 = p.GetVar("texto5");
var texto6 = p.GetVar("texto6");
var respuesta = [texto4,texto5,texto6];
var respuesta_04 = p.GetVar("respuesta_04");

if (respuesta != respuesta_04) {
  console.log("no es igual");
  window.setIntentos(cod_actividad, cod_diapositiva);
  //window.setLogro(cod_actividad, cod_diapositiva, logro);
  window.setRespuesta(cod_actividad, cod_diapositiva, respuesta);
} else {
  console.log("es igual");
}

console.log("intentos: ", window.getIntentos(cod_actividad, cod_diapositiva));
}

function Script10()
{
  var p = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

window.setEstadoSolucionario(cod_actividad, cod_diapositiva)

console.log("estado solucionario: ",window.getEstadoSolucionario(cod_actividad, cod_diapositiva));
}

function Script11()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

var texto7 = localStorage.getItem(cod_diapositiva + "_texto7");
var texto8 = localStorage.getItem(cod_diapositiva + "_texto8");
var texto9 = localStorage.getItem(cod_diapositiva + "_texto9");

console.log(texto7,texto8,texto9);
}

function Script12()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");
var texto7 = p.GetVar("texto7");
var texto8 = p.GetVar("texto8");
var texto9 = p.GetVar("texto9");
var respuesta = [texto7,texto8,texto9];
var respuesta_05 = p.GetVar("respuesta_05");

if (respuesta != respuesta_05) {
  console.log("no es igual");
  window.setIntentos(cod_actividad, cod_diapositiva);
  //window.setLogro(cod_actividad, cod_diapositiva, logro);
  window.setRespuesta(cod_actividad, cod_diapositiva, respuesta);
} else {
  console.log("es igual");
}

console.log("intentos: ", window.getIntentos(cod_actividad, cod_diapositiva));
}

function Script13()
{
  var p = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

window.setEstadoSolucionario(cod_actividad, cod_diapositiva)

console.log("estado solucionario: ",window.getEstadoSolucionario(cod_actividad, cod_diapositiva));
}

function Script14()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

var multi1 = localStorage.getItem(cod_diapositiva + "_multi1");
var multi2 = localStorage.getItem(cod_diapositiva + "_multi2");
var multi3 = localStorage.getItem(cod_diapositiva + "_multi3");
var multi4 = localStorage.getItem(cod_diapositiva + "_multi4");
var multi5 = localStorage.getItem(cod_diapositiva + "_multi5");
var multi6 = localStorage.getItem(cod_diapositiva + "_multi6");

console.log(multi1,multi2,multi3,multi4,multi5,multi6);
}

function Script15()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");
var logro = p.GetVar("logro");
var multi1 = p.GetVar("multi1");
var multi2 = p.GetVar("multi2");
var multi3 = p.GetVar("multi3");
var multi4 = p.GetVar("multi4");
var multi5 = p.GetVar("multi5");
var multi6 = p.GetVar("multi6");
var respuesta = [multi1,multi2,multi3,multi4,multi5,multi6];
var respuesta_06 = p.GetVar("respuesta_06");

if (respuesta != respuesta_06) {
  console.log("no es igual");
  window.setIntentos(cod_actividad, cod_diapositiva);
  window.setLogro(cod_actividad, cod_diapositiva, logro);
  window.setRespuesta(cod_actividad, cod_diapositiva, respuesta);
} else {
  console.log("es igual");
}

console.log("intentos: ", window.getIntentos(cod_actividad, cod_diapositiva));
}

function Script16()
{
  var p = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

window.setEstadoSolucionario(cod_actividad, cod_diapositiva)

console.log("estado solucionario: ",window.getEstadoSolucionario(cod_actividad, cod_diapositiva));
}

function Script17()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

var texto10 = localStorage.getItem(cod_diapositiva + "_texto10");
var texto11 = localStorage.getItem(cod_diapositiva + "_texto11");
var texto12 = localStorage.getItem(cod_diapositiva + "_texto12");

console.log(texto10,texto11,texto12);
}

function Script18()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");
var texto10 = p.GetVar("texto10");
var texto11 = p.GetVar("texto11");
var texto12 = p.GetVar("texto12");
var respuesta = [texto10,texto11,texto12];
var respuesta_07 = p.GetVar("respuesta_07");

if (respuesta != respuesta_07) {
  console.log("no es igual");
  window.setIntentos(cod_actividad, cod_diapositiva);
  //window.setLogro(cod_actividad, cod_diapositiva, logro);
  window.setRespuesta(cod_actividad, cod_diapositiva, respuesta);
} else {
  console.log("es igual");
}

console.log("intentos: ", window.getIntentos(cod_actividad, cod_diapositiva));
}

function Script19()
{
  var p = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

window.setEstadoSolucionario(cod_actividad, cod_diapositiva)

console.log("estado solucionario: ",window.getEstadoSolucionario(cod_actividad, cod_diapositiva));
}

function Script20()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

var texto13 = localStorage.getItem(cod_diapositiva + "_texto13");
var texto14 = localStorage.getItem(cod_diapositiva + "_texto14");
var texto15 = localStorage.getItem(cod_diapositiva + "_texto15");

console.log(texto13,texto14,texto15);
}

function Script21()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");
var texto13 = p.GetVar("texto13");
var texto14 = p.GetVar("texto14");
var texto15 = p.GetVar("texto15");
var respuesta = [texto13,texto14,texto15];
var respuesta_08 = p.GetVar("respuesta_08");

if (respuesta != respuesta_08) {
  console.log("no es igual");
  window.setIntentos(cod_actividad, cod_diapositiva);
  //window.setLogro(cod_actividad, cod_diapositiva, logro);
  window.setRespuesta(cod_actividad, cod_diapositiva, respuesta);
} else {
  console.log("es igual");
}

console.log("intentos: ", window.getIntentos(cod_actividad, cod_diapositiva));
}

function Script22()
{
  var p = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

window.setEstadoSolucionario(cod_actividad, cod_diapositiva)

console.log("estado solucionario: ",window.getEstadoSolucionario(cod_actividad, cod_diapositiva));
}

function Script23()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");
var logro = p.GetVar("logro");
var respuesta = p.GetVar("respuesta");
var respuesta_09 = p.GetVar("respuesta_09");

if (respuesta != respuesta_09) {
  console.log("no es igual");
  window.setIntentos(cod_actividad, cod_diapositiva);
  window.setLogro(cod_actividad, cod_diapositiva, logro);
  window.setRespuesta(cod_actividad, cod_diapositiva, respuesta);
} else {
  console.log("es igual");
}

console.log("intentos: ", window.getIntentos(cod_actividad, cod_diapositiva));
}

function Script24()
{
  var p = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

window.setEstadoSolucionario(cod_actividad, cod_diapositiva)

console.log("estado solucionario: ",window.getEstadoSolucionario(cod_actividad, cod_diapositiva));
}

function Script25()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");
var logro = p.GetVar("logro");
var respuesta = p.GetVar("respuesta");
var respuesta_10 = p.GetVar("respuesta_10");

if (respuesta != respuesta_10) {
  console.log("no es igual");
  window.setIntentos(cod_actividad, cod_diapositiva);
  window.setLogro(cod_actividad, cod_diapositiva, logro);
  window.setRespuesta(cod_actividad, cod_diapositiva, respuesta);
} else {
  console.log("es igual");
}

console.log("intentos: ", window.getIntentos(cod_actividad, cod_diapositiva));
}

function Script26()
{
  var p = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

window.setEstadoSolucionario(cod_actividad, cod_diapositiva)

console.log("estado solucionario: ",window.getEstadoSolucionario(cod_actividad, cod_diapositiva));
}

function Script27()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");
var logro = p.GetVar("logro");
var respuesta = p.GetVar("respuesta");
var respuesta_11 = p.GetVar("respuesta_11");

if (respuesta != respuesta_11) {
  console.log("no es igual");
  window.setIntentos(cod_actividad, cod_diapositiva);
  window.setLogro(cod_actividad, cod_diapositiva, logro);
  window.setRespuesta(cod_actividad, cod_diapositiva, respuesta);
} else {
  console.log("es igual");
}

console.log("intentos: ", window.getIntentos(cod_actividad, cod_diapositiva));
}

function Script28()
{
  var p = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

window.setEstadoSolucionario(cod_actividad, cod_diapositiva)

console.log("estado solucionario: ",window.getEstadoSolucionario(cod_actividad, cod_diapositiva));
}

function Script29()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");
var logro = p.GetVar("logro");
var respuesta = p.GetVar("respuesta");
var respuesta_12 = p.GetVar("respuesta_12");

if (respuesta != respuesta_12) {
  console.log("no es igual");
  window.setIntentos(cod_actividad, cod_diapositiva);
  window.setLogro(cod_actividad, cod_diapositiva, logro);
  window.setRespuesta(cod_actividad, cod_diapositiva, respuesta);
} else {
  console.log("es igual");
}

console.log("intentos: ", window.getIntentos(cod_actividad, cod_diapositiva));
}

function Script30()
{
  var p = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

window.setEstadoSolucionario(cod_actividad, cod_diapositiva)

console.log("estado solucionario: ",window.getEstadoSolucionario(cod_actividad, cod_diapositiva));
}

function Script31()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");
var logro = p.GetVar("logro");
var respuesta = p.GetVar("respuesta");
var respuesta_13 = p.GetVar("respuesta_13");

if (respuesta != respuesta_13) {
  console.log("no es igual");
  window.setIntentos(cod_actividad, cod_diapositiva);
  window.setLogro(cod_actividad, cod_diapositiva, logro);
  window.setRespuesta(cod_actividad, cod_diapositiva, respuesta);
} else {
  console.log("es igual");
}

console.log("intentos: ", window.getIntentos(cod_actividad, cod_diapositiva));
}

function Script32()
{
  var p = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

window.setEstadoSolucionario(cod_actividad, cod_diapositiva)

console.log("estado solucionario: ",window.getEstadoSolucionario(cod_actividad, cod_diapositiva));
}

function Script33()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

var drag1 = localStorage.getItem(cod_diapositiva + "_drag1")
var drag2 = localStorage.getItem(cod_diapositiva + "_drag2")
var drag3 = localStorage.getItem(cod_diapositiva + "_drag3")
var drag4 = localStorage.getItem(cod_diapositiva + "_drag4")
var drag5 = localStorage.getItem(cod_diapositiva + "_drag5")

console.log(drag1,drag2,drag3,drag4,drag5);
}

function Script34()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");
var logro = p.GetVar("logro");
var drag1 = p.GetVar("drag1");
var drag2 = p.GetVar("drag2");
var drag3 = p.GetVar("drag3");
var drag4 = p.GetVar("drag4");
var drag5 = p.GetVar("drag5");
var respuesta = [drag1,drag2,drag3,drag4,drag5];
var respuesta_14 = p.GetVar("respuesta_14");

if (respuesta != respuesta_14) {
  console.log("no es igual");
  window.setIntentos(cod_actividad, cod_diapositiva);
  window.setLogro(cod_actividad, cod_diapositiva, logro);
  window.setRespuesta(cod_actividad, cod_diapositiva, respuesta);
} else {
  console.log("es igual");
}

console.log("intentos: ", window.getIntentos(cod_actividad, cod_diapositiva));
}

function Script35()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

window.setEstadoSolucionario(cod_actividad, cod_diapositiva);

console.log("estado solucionario: ", window.getEstadoSolucionario(cod_actividad, cod_diapositiva));
}

function Script36()
{
  var p = GetPlayer();
player = GetPlayer();
var cod_actividad = p.GetVar("cod_actividad");
var cod_diapositiva = p.GetVar("cod_diapositiva");

var respuesta_01 = window.getRespuesta(cod_actividad, cod_actividad+"D01");
var respuesta_02 = window.getRespuesta(cod_actividad, cod_actividad+"D02");
var respuesta_03 = window.getRespuesta(cod_actividad, cod_actividad+"D03");
var respuesta_04 = window.getRespuesta(cod_actividad, cod_actividad+"D04");
var respuesta_05 = window.getRespuesta(cod_actividad, cod_actividad+"D05");
var respuesta_06 = window.getRespuesta(cod_actividad, cod_actividad+"D06");
var respuesta_07 = window.getRespuesta(cod_actividad, cod_actividad+"D07");
var respuesta_08 = window.getRespuesta(cod_actividad, cod_actividad+"D08");
var respuesta_09 = window.getRespuesta(cod_actividad, cod_actividad+"D09");
var respuesta_10 = window.getRespuesta(cod_actividad, cod_actividad+"D10");
var respuesta_11 = window.getRespuesta(cod_actividad, cod_actividad+"D11");
var respuesta_12 = window.getRespuesta(cod_actividad, cod_actividad+"D12");
var respuesta_13 = window.getRespuesta(cod_actividad, cod_actividad+"D13");
var respuesta_14 = window.getRespuesta(cod_actividad, cod_actividad+"D14");

var solucion_01 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D01");
var solucion_02 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D02");
var solucion_03 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D03");
var solucion_04 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D04");
var solucion_05 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D05");
var solucion_06 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D06");
var solucion_07 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D07");
var solucion_08 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D08");
var solucion_09 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D09");
var solucion_10 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D10");
var solucion_11 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D11");
var solucion_12 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D12");
var solucion_13 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D13");
var solucion_14 = window.getEstadoSolucionario(cod_actividad, cod_actividad+"D14");

var intento_01 = window.getIntentos(cod_actividad, cod_actividad+"D01");
var intento_02 = window.getIntentos(cod_actividad, cod_actividad+"D02");
var intento_03 = window.getIntentos(cod_actividad, cod_actividad+"D03");
var intento_04 = window.getIntentos(cod_actividad, cod_actividad+"D04");
var intento_05 = window.getIntentos(cod_actividad, cod_actividad+"D05");
var intento_06 = window.getIntentos(cod_actividad, cod_actividad+"D06");
var intento_07 = window.getIntentos(cod_actividad, cod_actividad+"D07");
var intento_08 = window.getIntentos(cod_actividad, cod_actividad+"D08");
var intento_09 = window.getIntentos(cod_actividad, cod_actividad+"D09");
var intento_10 = window.getIntentos(cod_actividad, cod_actividad+"D10");
var intento_11 = window.getIntentos(cod_actividad, cod_actividad+"D11");
var intento_12 = window.getIntentos(cod_actividad, cod_actividad+"D12");
var intento_13 = window.getIntentos(cod_actividad, cod_actividad+"D13");
var intento_14 = window.getIntentos(cod_actividad, cod_actividad+"D14");

var logro_01 = window.getLogro(cod_actividad, cod_actividad+"D01");
var logro_02 = window.getLogro(cod_actividad, cod_actividad+"D02");
var logro_03 = window.getLogro(cod_actividad, cod_actividad+"D03");
var logro_04 = window.getLogro(cod_actividad, cod_actividad+"D04");
var logro_05 = window.getLogro(cod_actividad, cod_actividad+"D05");
var logro_06 = window.getLogro(cod_actividad, cod_actividad+"D06");
var logro_07 = window.getLogro(cod_actividad, cod_actividad+"D07");
var logro_08 = window.getLogro(cod_actividad, cod_actividad+"D08");
var logro_09 = window.getLogro(cod_actividad, cod_actividad+"D09");
var logro_10 = window.getLogro(cod_actividad, cod_actividad+"D10");
var logro_11 = window.getLogro(cod_actividad, cod_actividad+"D11");
var logro_12 = window.getLogro(cod_actividad, cod_actividad+"D12");
var logro_13 = window.getLogro(cod_actividad, cod_actividad+"D13");
var logro_14 = window.getLogro(cod_actividad, cod_actividad+"D14");

var arrDiapos = ["D06","D09","D10","D11","D12","D13","D14"];

window.getTotal(cod_actividad,arrDiapos);
}

